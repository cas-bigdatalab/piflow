from langchain_huggingface import HuggingFaceEmbeddings as hfe
from sys import argv
from data_connect import DATAConnect
import typing as t
import weaviate as wv
import weaviate.classes as wvc
import warnings
import csv, json, os, time
from helpers import *

embed_provider:str
headers:t.Optional[t.Dict[str, str]] = None
collection_name:str

host:t.Optional[str] = ""
port:t.Optional[int] = 8080
grpc_host:t.Optional[str] = ""
grpc_port:t.Optional[int] = 50051
batch_size:int = 100

def write_dict(*args, elements_dict:t.List[t.Dict[str, t.Any]], **kwargs) -> None:
    embedFunc = hfe(model_name=embed_provider)
    client:wv.WeaviateClient
    collection:wv.collections.Collection

    def _embedText(s:str) -> t.List[float]:
        return embedFunc.embed_documents(texts=[s])[0]
    # ඞ sus
    # if path:
    #     client = wv.connect_to_local(host=host,
    #                                  port=port,
    #                                  grpc_port=grpc_port,
    #                                  headers=headers,
    #                                  skip_init_checks=True) # skip init checks if nessicary
    
    if host and port:
        client = wv.connect_to_custom(http_host=host,
                                      http_port=port,
                                      http_secure=False,
                                      grpc_host=grpc_host,
                                      grpc_port=grpc_port,
                                      grpc_secure=False,
                                      headers=headers,
                                      skip_init_checks=True) # skip init checks if neccisary
    
    else:
        client = wv.connect_to_local(skip_init_checks=True)
        warnings.warn("ephemerial client created due to abscence of path, host or port. Database will be deleted once process ends")
    
    try:
        try:
            collection = client.collections.get(collection_name)
        except:
            client.collections.create(
                name=collection_name,
                properties=[wvc.config.Property(name="filename", data_type=wvc.config.DataType.TEXT),
                            wvc.config.Property(name="filetype", data_type=wvc.config.DataType.TEXT),
                            wvc.config.Property(name="languages", data_type=wvc.config.DataType.TEXT),
                            wvc.config.Property(name="page_number", data_type=wvc.config.DataType.TEXT),
                            wvc.config.Property(name="text", data_type=wvc.config.DataType.TEXT),
                            wvc.config.Property(name="type", data_type=wvc.config.DataType.TEXT)],
                vectorizer_config=[wvc.config.Configure.NamedVectors.none("filename"),
                                   wvc.config.Configure.NamedVectors.none("filetype"),
                                   wvc.config.Configure.NamedVectors.none("languages"),
                                   wvc.config.Configure.NamedVectors.none("page_number"),
                                   wvc.config.Configure.NamedVectors.none("text"),
                                   wvc.config.Configure.NamedVectors.none("type")],
                generative_config=wvc.config.Configure.Generative.openai()
            )

        with collection.batch.fixed_size(batch_size=batch_size) as batch:
            for e in elements_dict:
                vectors:dict[str,list[float]] = {}
                for k in list(e.keys()):
                    vectors[str(k)] = _embedText(str(e[k]))
                batch.add_object(properties=e, vector=vectors)
            batch.flush()
    
    finally:
        client.close()



if __name__ == "__main__":
    dataConnect = DATAConnect()
    #固定参数
    # 获取组件配置参数
    collection_name = argv[1]
    batch_size = int(argv[2])
    host = argv[3]
    port = int(argv[4])
    grpc_host = argv[5]
    if not grpc_host:
        grpc_host = host
        
    grpc_port = argv[6]
    embed_provider = embed_change(argv[7])

    df = dataConnect.dataInputStream(port="input_read")
    df.drop_duplicates(subset=["element_id"], inplace=True)

    datas:t.List[t.Dict[str, t.Any]] = []
    for i in range(0, len(df.axes[0])):
        dic:t.Dict[str, str] = {}
        dic["filename"] = df.iloc[i]["metadata"]["filename"]
        dic["filetype"] = df.iloc[i]["metadata"]["filetype"]
        dic["languages"] = str(df.iloc[i]["metadata"]["languages"])
        dic["page_number"] = str(df.iloc[i]["metadata"]["page_number"])
        dic["text"] = str(df.iloc[i]["text"])
        dic["type"] = df.iloc[i]["type"]
        datas.append(dic)

    write_dict(elements_dict=datas, batch_size=batch_size)