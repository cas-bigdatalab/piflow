"""
author:zhenghao@tamu.edu
"""
import os, warnings, csv, json, itertools
from sys import argv
import pandas as pd
import numpy as np
import typing as t
import chromadb as cdb
from data_connect import DATAConncet
from chromadb.config import DEFAULT_TENANT, DEFAULT_DATABASE
from chromadb.utils import embedding_functions as ef
from helpers import *

dataConnect:DATAConncet

# 获取组件配置参数
embed_provider:str = None
settings:t.Optional[t.Dict[str, str]] = None
collection_name:str = None
path:t.Optional[str] = None
tenant:t.Optional[str] = DEFAULT_TENANT
database:t.Optional[str] = DEFAULT_DATABASE
batch_size:int = 100


def write_dict(*args, elements_dict: t.List[t.Dict[str, t.Any]], **kwargs) -> None:
    client:cdb.ClientAPI
    embedFunc = ef.SentenceTransformerEmbeddingFunction(model_name=embed_provider)

    if path:
        client = cdb.PersistentClient(path=path, 
                                      settings=settings,
                                      tenant=tenant,
                                      database=database)   
    else:
        client = cdb.Client()
        warnings.warn("ephemerial client created due to abscence of path, host or port. Database will be deleted once process ends")
        
    #currently using default embed function
    collection = client.get_or_create_collection(name=collection_name, embedding_function=embedFunc)
    
    for l in chunk_generator(elements_dict, batch_size):
        t = transpose(l)
        try:
            collection.add(ids=t["id"], documents=t["document"], metadatas=t["metadata"])
        except Exception as e:
            raise ValueError(f"Chroma error:{e}") from e


if __name__ == '__main__':
    os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"
    dataConnect = DATAConncet() # Disabled for testing basic functionality
    # 获取组件配置参数
    collection_name = argv[1]
    path = argv[2]
    batch_size = int(argv[3])
    tenant = argv[4]
    database = argv[5]
    embed_provider = embed_change(argv[6])

    df = dataConnect.dataInputStream(port="input_read")
    df.drop_duplicates(subset=["element_id"], inplace=True)

    datas:t.List[t.Dict[str, t.Any]] = []
    for i in range(0, len(df.axes[0])):
        dic:t.Dict[str, t.Any] = {}
        dic["id"] = df.iloc[i]["element_id"]
        dic["document"] = df.iloc[i]["text"]
        dic["metadata"] = df.iloc[i]["metadata"]

        dic["metadata"]["languages"] = str(dic["metadata"]["languages"])

        if "parent_id" not in dic.keys():
            dic["metadata"]["parent_id"] = ""

        datas.append(dic)

    write_dict(elements_dict=datas, batch_size=batch_size)