from langchain_huggingface import HuggingFaceEmbeddings as hfe
from langchain_community.vectorstores import FAISS
from sys import argv
import typing as t
import warnings
from data_connect import DATAConncet
from helpers import *


embed_provider:str
collection_name:str
path:t.Optional[str] = None
batch_size:int = 100


def write_dict(*args, elements_dict: t.List[t.Dict[str, t.Any]], **kwargs) -> None:
    embedFunc = hfe(model_name=embed_provider)
    fs:FAISS
    alrExist = False

    try:
        fs = FAISS.load_local(folder_path=path, index_name=collection_name, allow_dangerous_deserialization=True)
        alrExist = True
    except:
        fs = FAISS.from_texts(texts=["test"], ids=["a"], embedding=embedFunc)
        fs.delete(ids=["a"]) # initiate a client and also test an embedding


    for c in chunk_generator(elements_dict, batch_size):
        t = transpose(c)
        fs.add_texts(ids=t["id"], texts=t["document"], metadatas=t["metadata"])

    if not alrExist:
        fs.save_local(folder_path=path, index_name=collection_name)


if __name__ == "__main__":
    dataConnect = DATAConncet() # Disabled for testing basic functionality
    # 获取组件配置参数
    collection_name = argv[1]
    path = argv[2]
    batch_size = int(argv[3])
    embed_provider = embed_change(argv[4])

    df = dataConnect.dataInputStream(port="input_read")
    df.drop_duplicates(subset=["element_id"], inplace=True)

    datas:t.List[t.Dict[str, t.Any]] = []
    for i in range(0, len(df.axes[0])):
        dic:t.Dict[str, t.Any] = {}
        dic["id"] = df.iloc[i]["element_id"]
        dic["document"] = df.iloc[i]["text"]
        dic["metadata"] = df.iloc[i]["metadata"]
        datas.append(dic)

    write_dict(elements_dict=datas, batch_size=batch_size)
