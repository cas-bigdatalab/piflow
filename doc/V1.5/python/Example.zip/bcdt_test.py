# -*- coding: utf-8 -*-

import os
from data_connect import DATAConncet
from sys import argv
import pandas as pd
import numpy as np


if __name__ == '__main__':
    dataConnect = DATAConncet()
    
    # 获取上游传递数据（路径 ）
 
    input_file = argv[1]
    result_tif_path = argv[2]

    dataConnect.downloadFileFromHdfs(input_file, input_file, False)
    dataConnect.putFileToHdfs(result_tif_path,input_file)
 
    df = pd.DataFrame({'out_path': [result_tif_path]})
    print(df)

